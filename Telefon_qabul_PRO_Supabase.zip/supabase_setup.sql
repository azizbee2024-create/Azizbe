-- Telefon qabul PRO: umumiy bulut bazasi
-- Supabase Dashboard -> SQL Editor -> New query -> shu fayldagi SQL'ni to'liq Run qiling.
-- Faqat Supabase Auth orqali kirgan foydalanuvchilar ishlata oladi.
-- Supabase Authentication sozlamalarida yangi ochiq ro'yxatdan o'tishni o'chirib qo'ying,
-- va faqat o'zingiz yaratgan 3 ta hisobdan foydalaning.

create table if not exists public.phone_inventory_shared (
  id text primary key check (id = 'shared'),
  payload jsonb not null default '{"items":[],"cfg":{"cur":"$","theme":"auto"},"tac":{}}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.phone_inventory_shared enable row level security;

drop policy if exists "signed_in_users_read_shared_inventory" on public.phone_inventory_shared;
create policy "signed_in_users_read_shared_inventory"
on public.phone_inventory_shared
for select
to authenticated
using (true);

drop policy if exists "signed_in_users_insert_shared_inventory" on public.phone_inventory_shared;
create policy "signed_in_users_insert_shared_inventory"
on public.phone_inventory_shared
for insert
to authenticated
with check (id = 'shared');

drop policy if exists "signed_in_users_update_shared_inventory" on public.phone_inventory_shared;
create policy "signed_in_users_update_shared_inventory"
on public.phone_inventory_shared
for update
to authenticated
using (true)
with check (id = 'shared');

grant select, insert, update on public.phone_inventory_shared to authenticated;
