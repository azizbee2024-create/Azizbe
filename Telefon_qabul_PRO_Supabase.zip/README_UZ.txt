TELEFON QABUL PRO — O‘RNATISH

1) Supabase loyihangizni oching: https://supabase.com/dashboard
2) Chap menyu: SQL Editor → New query.
3) supabase_setup.sql faylini ochib, ichidagi HAMMA SQL kodni nusxalang, SQL Editor’ga joylang va Run bosing.
4) Supabase → Authentication → Users bo‘limida uchala hisob mavjudligini tekshiring. Xodimlar oldindan yaratilgan email/parol bilan kiradi.
5) Authentication sozlamalarida ochiq Sign ups/ro‘yxatdan o‘tishni o‘chirib qo‘ying; faqat o‘zingiz yaratgan hisoblar ishlasin.
6) index.html faylini Netlify Drop’ga joylang yoki hozirgi Netlify saytingizdagi fayl bilan almashtiring.
7) Har bir hisob bilan kirib, bitta test telefon qo‘shing; boshqa hisobda yangilang. Bitta umumiy zaxirada ko‘rinsa, ulanish ishlayapti.

MUHIM:
- Bu versiyada kelgan narx barcha kirgan xodimlarga ko‘rinadi.
- Hozirgi fayl umumiy inventar ro‘yxatini bitta JSON yozuvda saqlaydi; ikki kishi ayni paytda bir-birining o‘zgarishini ustidan yozib yubormasligi uchun bir vaqtda tahrirni ehtiyot qiling.
- Mavjud eski ma’lumotlar avtomatik ravishda Supabase’ga ko‘chirilmaydi. Avvalgi telefonlar kerak bo‘lsa, eski qurilmadagi zaxira nusxani eksport qilish/ko‘chirish kerak.
- Publishable/anon kalit brauzerda ishlatilishi mumkin; sb_secret yoki service_role kalitini HTML ichiga hech qachon qo‘ymang.
